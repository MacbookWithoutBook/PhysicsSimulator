package com.bignerdranch.android.physicsSim.entities;

public enum ObjectType {
    CUBE, SPHERE, CAR
}
